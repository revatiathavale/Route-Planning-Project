#include "../src/pugixml.hpp"

#if PUGIXML_VERSION != 190
#error Unexpected pugixml version
#endif
